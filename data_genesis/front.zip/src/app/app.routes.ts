import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ComposantGeneraliseComponent } from './composant-generalise/composant-generalise.component'; // Assurez-vous de spécifier le bon chemin vers votre composant
import {AppComponent} from './app.component';
export const routes: Routes = [
    {path:'',redirectTo : '',pathMatch:'full'},
    { path: 'un', component: AppComponent },
    { path: 'test', component: ComposantGeneraliseComponent },
];
